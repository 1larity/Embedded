KNX header files. Workaround to exclude KNX library when not needed
